import MemoExemple from "./pages/MemoExemple";

function App() {
  return <MemoExemple />;
}

export default App;
