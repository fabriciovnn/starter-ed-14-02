/* eslint-disable react-hooks/exhaustive-deps */
import { useMemo, useState } from "react";

function MemoExemple() {
  const [num, setNum] = useState<number>(0);
  const [incremento, setIncremento] = useState<number>(1);

  const memoFatorial = useMemo(() => {
    if(num > 0) {
    return  fatorial(num)
    }
  }, [num]);

  function onChange(event: React.ChangeEvent<HTMLInputElement>): void {
    setNum(Number(event.target.value));
  }

  function onClick(): void {
    setIncremento(incremento + 1);
  }

    function fatorial(num: number): number {
      console.log("Fatorial chamado");
      if (num < 0) return -1;
      else if (num === 0) return 1;
      else {
        return num * fatorial(num - 1);
      }
    }

  return (
    <div>
      Fatorial de <input type="number" value={num} onChange={onChange} /> é 
        {memoFatorial}
        <br />
      <button onClick={onClick}>Reenderizar</button>
      {incremento}
    </div>
  );

}

export default MemoExemple;
