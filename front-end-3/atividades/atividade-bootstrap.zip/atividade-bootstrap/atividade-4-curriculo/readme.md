  <h1>Portfólio pessoal</h1>

 Esta é a atividade final do módulo de front end 1.
 Neste projeto foi utilizado:
- Html
- CSS ( utilizando apenas float e position)

Possui:
- Páginas para navegação
- Links para contato e redes sociais


