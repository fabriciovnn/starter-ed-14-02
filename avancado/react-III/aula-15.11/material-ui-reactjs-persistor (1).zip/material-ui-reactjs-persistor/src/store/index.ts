import { store, RootState, AppDispatch, persistor } from './store';

export { store, persistor };
export type { RootState, AppDispatch };
